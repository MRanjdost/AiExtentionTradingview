// Initialize the service worker
self.addEventListener('install', (event) => {
  console.log('Service Worker installing...');
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  console.log('Service Worker activating...');
});

// Initialize screenshot counter
// Initialize screenshot counter and load from storage
let screenshotCounter = 0;

// Load counter from storage on startup
chrome.storage.local.get('screenshotCounter', (result) => {
  if (result.screenshotCounter !== undefined) {
    screenshotCounter = result.screenshotCounter;
    console.log('Loaded screenshot counter:', screenshotCounter);
  }
});

// Function to verify webhook settings
async function verifySettings() {
  console.log('Verifying webhook settings...');
  const settings = await chrome.storage.sync.get(['webhookUrl']);

  if (!settings.webhookUrl) {
    throw new Error('Webhook URL not configured');
  }

  return settings;
}

// Function to convert base64 to binary blob
function base64ToBlob(base64Data) {
  // Remove the data URL prefix if present
  const base64String = base64Data.replace(/^data:image\/\w+;base64,/, '');
  
  // Convert base64 to binary
  const byteCharacters = atob(base64String);
  const byteArrays = [];

  for (let offset = 0; offset < byteCharacters.length; offset += 512) {
    const slice = byteCharacters.slice(offset, offset + 512);
    const byteNumbers = new Array(slice.length);
    
    for (let i = 0; i < slice.length; i++) {
      byteNumbers[i] = slice.charCodeAt(i);
    }
    
    byteArrays.push(new Uint8Array(byteNumbers));
  }

  return new Blob(byteArrays, { type: 'image/png' });
}

// Function to show notification
function showNotification(title, message, isError = false) {
  console.log('Showing notification:', { title, message, isError });
  
  const notificationOptions = {
    type: 'basic',
    title: title,
    message: message,
    iconUrl: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=='
  };

  try {
    chrome.notifications.create(String(Date.now()), notificationOptions, (notificationId) => {
      if (chrome.runtime.lastError) {
        console.error('Notification error:', chrome.runtime.lastError);
      } else {
        console.log('Notification created:', notificationId);
      }
    });
  } catch (error) {
    console.error('Error creating notification:', error);
  }
}

// Screenshot handler
async function handleScreenshot(tabId, sendResponse) {
  console.log('Starting screenshot process for tab:', tabId);
  
  try {
    // Verify settings first
    const settings = await verifySettings();
    console.log('Webhook settings verified');

    // Take screenshot
    console.log('Capturing screenshot...');
    const screenshot = await chrome.tabs.captureVisibleTab(null, { format: 'png' });
    console.log('Screenshot captured');

    // Convert base64 to binary blob
    const binaryData = base64ToBlob(screenshot);
    console.log('Converted to binary data');

    // Upload screenshot
    console.log('Starting upload to webhook...');
    const response = await fetch(settings.webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'image/png',
      },
      body: binaryData
    });

    // Get response text
    const responseText = await response.text();
    console.log('Response received:', responseText);

    if (!response.ok) {
      throw new Error(`Upload failed: ${response.status} ${response.statusText}`);
    }

    // Store screenshot and analysis data
    const currentId = screenshotCounter;
    await chrome.storage.local.set({
      [`screenshot_${currentId}`]: screenshot,
      [`analysis_${currentId}`]: { response: responseText }
    });

    console.log('Upload successful');

    // Store data before opening tab
    await chrome.storage.local.set({
      [`screenshot_${currentId}`]: screenshot,
      [`analysis_${currentId}`]: { response: responseText }
    });
    console.log('Data stored for result tab');

    // Save to history
    console.log('Updating screenshot history...');
    const result = await chrome.storage.local.get('screenshots');
    const screenshots = result.screenshots || [];
    
    screenshots.push({
      id: screenshotCounter,
      timestamp: new Date().toISOString()
    });

    await chrome.storage.local.set({ screenshots: screenshots });
    console.log('Screenshot history updated');
    
    // Increment counter and save it
    screenshotCounter++;
    await chrome.storage.local.set({ screenshotCounter });
    console.log('Updated screenshot counter:', screenshotCounter);

    // Open result tab after data is stored
    chrome.tabs.create({
      url: chrome.runtime.getURL('result.html'),
      active: true
    });

    // Show success notification
    showNotification(
      'Analysis Complete',
      'Check the popup for results'
    );

    // Try to send the response to any open popups
    try {
      chrome.runtime.sendMessage({
        type: 'ANALYSIS_RESULT',
        result: responseText
      }).catch(() => {
        console.log('No popup available to receive result');
      });
    } catch (error) {
      console.log('Error sending result to popup:', error);
    }

    // Send response back to popup
    if (sendResponse) {
      sendResponse({
        success: true,
        response: responseText
      });
    }

  } catch (error) {
    console.error('Screenshot process error:', error);
    showNotification(
      'Screenshot Error',
      error.message,
      true
    );

    // Try to send the error to any open popups
    try {
      chrome.runtime.sendMessage({
        type: 'ANALYSIS_ERROR',
        error: error.message
      }).catch(() => {
        console.log('No popup available to receive error');
      });
    } catch (error) {
      console.log('Error sending error to popup:', error);
    }

    // Send error back to popup
    if (sendResponse) {
      sendResponse({
        success: false,
        error: error.message
      });
    }
  }
}

// Message listener
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Message received:', request);
  
  if (request.action === 'takeScreenshot') {
    if (!request.tabId) {
      console.error('No tab ID provided');
      sendResponse({
        success: false,
        error: 'No tab ID provided'
      });
      return false;
    }
    
    // Handle screenshot and send response
    handleScreenshot(request.tabId, sendResponse);
    return true; // Will respond asynchronously
  }
  
  return false;
});

// Add this function to check if URL is allowed
function isAllowedUrl(url) {
  return url.match(/^https?:\/\/([^\/]+\.)?tradingview\.com/i) !== null;
}

// Modify the existing chrome.tabs.onActivated listener or add it if it doesn't exist
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    const isAllowed = isAllowedUrl(tab.url);
    
    // Send message only to active popup if it exists
    chrome.runtime.sendMessage({ type: 'URL_CHECK', isAllowed }).catch(() => {
      // Ignore errors when popup is not open
      console.log('Popup not available, message not sent');
    });
  } catch (error) {
    console.error('Error in onActivated listener:', error);
  }
});

// Also listen for tab updates
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url) {
    const isAllowed = isAllowedUrl(changeInfo.url);
    
    // Send message only to active popup if it exists
    chrome.runtime.sendMessage({ type: 'URL_CHECK', isAllowed }).catch(() => {
      // Ignore errors when popup is not open
      console.log('Popup not available, message not sent');
    });
  }
}); 