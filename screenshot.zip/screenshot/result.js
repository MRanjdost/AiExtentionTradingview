document.addEventListener('DOMContentLoaded', () => {
  const screenshotImg = document.getElementById('screenshotImg');
  const analysisResult = document.getElementById('analysisResult');
  const refreshBtn = document.getElementById('refreshBtn');
  const closeBtn = document.getElementById('closeBtn');
  const timestampEl = document.getElementById('screenshotTimestamp');

  // Load latest analysis result
  async function loadLatestResult() {
    try {
      // Get latest screenshot ID from history
      const { screenshots = [] } = await chrome.storage.local.get('screenshots');
      if (screenshots.length === 0) {
        analysisResult.textContent = 'No analysis data available';
        return;
      }

      const latest = screenshots[screenshots.length - 1];
      const latestId = latest.id;
      
      // Get both screenshot and analysis data
      const result = await chrome.storage.local.get([
        `screenshot_${latestId}`,
        `analysis_${latestId}`
      ]);

      if (!result[`screenshot_${latestId}`] || !result[`analysis_${latestId}`]) {
        throw new Error('Failed to load analysis data');
      }
      
      // Display the data
      analysisResult.textContent = result[`analysis_${latestId}`].response;
      screenshotImg.src = result[`screenshot_${latestId}`];
      timestampEl.textContent = new Date(latest.timestamp).toLocaleString();
      
      if (result[`analysis_${latest.id}`]) {
        analysisResult.textContent = result[`analysis_${latest.id}`].response;
        timestampEl.textContent = new Date(latest.timestamp).toLocaleString();
        
        // Load screenshot from storage
        const screenshot = await chrome.storage.local.get(`screenshot_${latest.id}`);
        if (screenshot[`screenshot_${latest.id}`]) {
          screenshotImg.src = screenshot[`screenshot_${latest.id}`];
        }
      }
    } catch (error) {
      console.error('Error loading results:', error);
      analysisResult.textContent = `Error loading analysis results: ${error.message}`;
      analysisResult.style.color = 'var(--error)';
    }
  }

  // Refresh results
  refreshBtn.addEventListener('click', async () => {
    analysisResult.textContent = 'Refreshing...';
    screenshotImg.src = '';
    await loadLatestResult();
  });

  // Close window
  closeBtn.addEventListener('click', () => {
    window.close();
  });

  // Initial load
  loadLatestResult();
});